Fork it!
Create your feature/module branch: git checkout -b my-new-module
Commit your changes: git commit -am 'Add some module'
Push to the branch: git push origin my-new-module
Submit a pull request